﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using LodenSynch.Models;
using Newtonsoft.Json;

namespace LodenSynch.Operations
{
    class ApiOperations
    {
        /**
         * Base Url @string
         */
        private string baseUrl;
        private List<Record> records;

        public ApiOperations()
        {
            // this.baseUrl = "http://api.ezi-api.com:87";
        }

        /**
         * Authenticate user with Web Api Endpoint
         * @param string username
         * @param string password
         */
        public User AuthenticateUser(string username, string password)
        {
            string endpoint = Globals.baseUrl + "/users/login";
            string method = "POST";
            string json = JsonConvert.SerializeObject(new
            {
                username = username,
                password = password
            });

            WebClient wc = new WebClient();
            wc.Headers["Content-Type"] = "application/json";
            wc.Headers["X-Token"] = "022121054520210622114749";
            try
            {
                string response = wc.UploadString(endpoint, method, json);
                return JsonConvert.DeserializeObject<User>(response);
            }
            catch (Exception)
            {
                return null;
            }
        }

        /**
         * Get User Details from Web Api
         * @param  User Model
         */
        public List<Event> GetUserDetails(User user)
        {
            string endpoint = Globals.baseUrl + "/users/getevents?OrganizationID=" + user.OrganizationID;
            string access_token = user.access_token;
            WebClient wc = new WebClient();
            wc.Headers["Content-Type"] = "application/json";
            wc.Headers["X-Token"] = "022121054520210622114749";
            wc.Headers["Authorization"] = "Bearer " + access_token;
            try
            {
                string response = wc.DownloadString(endpoint);
                List<Event> events = JsonConvert.DeserializeObject<List<Event>>(response);
                user.access_token = access_token;
                return events;
            }
            catch (Exception Ex)
            { 
                // System.Windows.MessageBox.Show(Ex.Message);
                return null;
            }
        }
        public List<Athlete> GetAthletes(User user, String EventID)
        {
            string endpoint = Globals.baseUrl + "/users/getathletes?OrganizationID=" + user.OrganizationID + "&EventID="+ EventID;
            string access_token = user.access_token;
            WebClient wc = new WebClient();
            wc.Headers["Content-Type"] = "application/json";
            wc.Headers["X-Token"] = "022121054520210622114749";
            wc.Headers["Authorization"] = "Bearer " + access_token;
            try
            {
                string response = wc.DownloadString(endpoint);
                List<Athlete> athletes = JsonConvert.DeserializeObject<List<Athlete>>(response);
                return athletes;
            }
            catch (Exception)
            {
                return null;
            }
        }
        public List<Test> GetTests(User user)
        {
            string endpoint = Globals.baseUrl + "/users/gettests";
            string access_token = user.access_token;
            WebClient wc = new WebClient();
            wc.Headers["Content-Type"] = "application/json";
            wc.Headers["X-Token"] = "022121054520210622114749";
            wc.Headers["Authorization"] = "Bearer " + access_token;
            try
            {
                string response = wc.DownloadString(endpoint);
                List<Test> tests = JsonConvert.DeserializeObject<List<Test>>(response);
                return tests;
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
