﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LodenSynch.Models
{
    public class User
    {
        public string user_id { get; set; }
        public string access_token { get; set; }
        public string token_type { get; set; }
        public string expires_in { get; set; }
        public int creation_time { get; set; }
        public int expiration_Time { get; set; }
        public string OrganizationID { get; set; }

    }
    public class Athlete
    {
        public String AthleteID { get; set; }
        public String FirstName { get; set; }
        public String LastName { get; set; }
        public String DOB { get; set; }
        public String Weight { get; set; }

    }
    public class Test
    {
        public String IDDefProva { get; set; }
        public String Nome { get; set; }
        public int Ambito { get; set; }
        public int TipoProva { get; set; }
        public int TipoPartenza { get; set; }
        public int Partenza { get; set; }
        public int TipoArrivo { get; set; }
        public int Arrivo { get; set; }
        public String Filmato { get; set; }
        public int NumSalti { get; set; }
        public int Durata { get; set; }
        public int Sequenza { get; set; }
        public int NumCount { get; set; }
        public String Note { get; set; }
        public String NumBlocchiWJ { get; set; }
        public String Immagine { get; set; }
        public int Bloccato { get; set; }
        public String Parametri { get; set; }
        public int PiedePartenza { get; set; }
        public String IndiciManuali { get; set; }
        public int Template { get; set; }

    }

    public class Event
    {
        public string EventID { get; set; }
        public string EventName { get; set; }

    }
    public class Record
    {
        public Event record;
    }
    public class CursorWait : IDisposable
    {
        public CursorWait(bool appStarting = false, bool applicationCursor = false)
        {
            // Wait
            Cursor.Current = appStarting ? Cursors.AppStarting : Cursors.WaitCursor;
            if (applicationCursor) Application.UseWaitCursor = true;
        }

        public void Dispose()
        {
            // Reset
            Cursor.Current = Cursors.Default;
            Application.UseWaitCursor = false;
        }
    }
}
