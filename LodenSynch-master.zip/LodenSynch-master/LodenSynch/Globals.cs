﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using LodenSynch.Models;

namespace LodenSynch
{
    class Globals
    {
        public static String baseUrl = "http://api.ezi-api.com:87";
        public static String datasource { get; set; }
        public static User LoggedInUser { get; set; } 
        public static List<Event> EventList { get; set; }

    }
}
