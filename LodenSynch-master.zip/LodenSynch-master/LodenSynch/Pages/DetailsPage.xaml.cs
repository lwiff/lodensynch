﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlServerCe;
using Newtonsoft.Json;
using System.Data;
using LodenSynch.Models;
using LodenSynch.Operations;
using System.Net.Http;


namespace LodenSynch.Pages
{
    /// <summary>
    /// Interaction logic for DetailsPage.xaml
    /// </summary>
    public partial class DetailsPage : Page
    {
        public DetailsPage()
        {
            InitializeComponent();
        }

        /**
         * Details Page Loaded
         * @param  object  sender
         * @param  RoutedEventArgs e
         */
        private void detailsPage_Loaded(object sender, RoutedEventArgs e)
        {
            List<Event> events = FetchEvents();
            Globals.EventList = events;
            ShowEvents(events);
            FileTextBox.IsReadOnly = true;
        }

        /**
         * Fetch User Details
         */
        private List<Event> FetchEvents()
        {
            ApiOperations ops = new ApiOperations();
            try
            {
                List<Event> records = ops.GetUserDetails(Globals.LoggedInUser);
                if (records == null)
                {
                    System.Windows.MessageBox.Show("There are no events listed for your organization");
                    // Navigate back to login page
                    NavigationService.Navigate(new LoginPage());
                }
                return records;
            }
            //Globals.LoggedInUser = user;
            catch (Exception e)
            {
                System.Windows.MessageBox.Show("There are no events listed for your organization");
                // Navigate back to login page
                NavigationService.Navigate(new LoginPage());
                return null;
            }
        }

        /**
         * Show User Info on the Screen
         */
        private void ShowEvents(List<Event> Events)
        {

            if (Events != null)
            {
                foreach (Event event1 in Events)
                {
                    EventBox.Items.Add(event1.EventName);
                }
            }
            else
            {
                NavigationService.Navigate(new LoginPage());
            }
        }

        /**
         * Logout Method to be called on the logout Button
         * @param  object sender
         * @param  RoutedEventArgs e
         */
        private Int32 SendJSON(string jsonstring, string endpoint)
        {
            HttpResponseMessage response = null;
            try
            {
                using (var client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Add("X-Token", "022121054520210622114749");
                    client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Globals.LoggedInUser.access_token);
                    response = client.PostAsync(
                    Globals.baseUrl + endpoint,
                    new StringContent(jsonstring, Encoding.UTF8, "application/json")).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        return 0;
                    }
                    else
                    {
                        return 1;
                    }
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(Globals.baseUrl + endpoint);
                return 2;
            }
        }

        private String sqlDatoToJson(SqlCeDataReader dataReader)
        {
            var dataTable = new DataTable();
            dataTable.Load(dataReader);
            string JSONString = string.Empty;
            JSONString = JsonConvert.SerializeObject(dataTable);
            return JSONString;
        }
        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            Globals.LoggedInUser = null;
            NavigationService.Navigate(new LoginPage());
        }
        private void btnClearDB_Click(object sender, RoutedEventArgs e)
        {
            Int32 affectedRows = 0;
            Int32 affectedRows1 = 0;
            Int32 affectedRows2 = 0;
            Int32 affectedRows3 = 0;
            MessageBoxResult dialogResult = System.Windows.MessageBox.Show("Are you sure you want to clear the data?", "Clearing of Data", MessageBoxButton.YesNo);
            if (dialogResult == MessageBoxResult.Yes)
            {
                if (FileTextBox.Text == "")
                {
                    System.Windows.MessageBox.Show("Please select a database");
                }
                else
                {
                    String exmessage;
                    SqlCeConnection conn = null;
                    ApiOperations ops = new ApiOperations();
                    try
                    {
                        conn = new SqlCeConnection("Data Source = " + FileTextBox.Text + ";Default Lock Timeout=10000");
                        conn.Open();
                        try
                        {
                            SqlCeCommand cmd = conn.CreateCommand();
                            cmd.CommandText = "DELETE FROM TablePersona";
                            affectedRows = cmd.ExecuteNonQuery();
                        }
                        catch (Exception Ex)
                        {
                            System.Windows.MessageBox.Show(Ex.Message);
                        }
                        
                        try
                        {
                            SqlCeCommand cmd = conn.CreateCommand();
                            cmd.CommandText = "DELETE FROM TablePersonaNodo";
                            affectedRows1 = cmd.ExecuteNonQuery();
                        }
                        catch (Exception Ex)
                        {
                            System.Windows.MessageBox.Show(Ex.Message);
                        }
                        
                        try
                        {
                            SqlCeCommand cmd = conn.CreateCommand();
                            cmd.CommandText = "DELETE FROM TableProva";
                            affectedRows2 = cmd.ExecuteNonQuery();
                        }
                        catch (Exception Ex)
                        {
                            System.Windows.MessageBox.Show(Ex.Message);
                        }
                        
                        try
                        {
                            SqlCeCommand cmd = conn.CreateCommand();
                            cmd.CommandText = "DELETE FROM TableResultData";
                            affectedRows3 = cmd.ExecuteNonQuery();
                        }
                        catch (Exception Ex)
                        {
                            System.Windows.MessageBox.Show(Ex.Message);
                        }
                        conn.Dispose();
                        conn.Close();
                        System.Windows.MessageBox.Show("Database Cleared.");
                    }
                    catch (Exception Ex)
                    {
                        System.Windows.MessageBox.Show(Ex.Message);
                    }
                }
            }
        }
        private void btnDownload_Click(object sender, RoutedEventArgs e)
        {
            String exmessage;
            SqlCeConnection conn = null;
            Int32 extype = 0;
            Int32 count = 0;
            Int32 lastrec = 0;
            ApiOperations ops = new ApiOperations();
            if (FileTextBox.Text == "")
            {
                System.Windows.MessageBox.Show("Please select a database");
            }
            else
            {
                if (EventBox.SelectedIndex >= 0)
                {
                    string selectedItem = EventBox.Items[EventBox.SelectedIndex].ToString();
                    foreach (Event ev in Globals.EventList)
                    {
                        if (ev.EventName == selectedItem)
                        {
                            selectedItem = ev.EventID;
                        }
                    }
                    if (selectedItem == "")
                    {
                        System.Windows.MessageBox.Show("Please select an event");
                    }
                    else
                    {
                        try
                        {
                            List<Athlete> Athletes = ops.GetAthletes(Globals.LoggedInUser, selectedItem);
                            if (Athletes == null)
                            {
                                System.Windows.MessageBox.Show("There are no athletes to download");
                            }
                            else
                            {
                                using (new CursorWait())
                                {
                                    try
                                    {
                                        conn = new SqlCeConnection("Data Source = " + FileTextBox.Text + ";");
                                        conn.Open();
                                        SqlCeCommand cmd2 = conn.CreateCommand();
                                        cmd2.CommandText = "SELECT TOP (1) Riga FROM TablePersona order by Riga DESC";
                                        try
                                        {
                                            lastrec = (int)cmd2.ExecuteScalar();
                                        }
                                        catch (NullReferenceException Ex)
                                        {
                                            lastrec = 0;
                                        }
                                        count = 0;
                                        int indb = lastrec;
                                        foreach (Athlete athlete in Athletes)
                                        {
                                            try
                                            {
                                                lastrec++;
                                                SqlCeCommand cmd4 = conn.CreateCommand();
                                                cmd4.CommandText = "SET IDENTITY_INSERT TablePersonaNodo OFF";
                                                Int32 result = (Int32)cmd4.ExecuteNonQuery();
                                                SqlCeCommand cmd5 = conn.CreateCommand();
                                                cmd5.CommandText = "SET IDENTITY_INSERT TablePersona ON";
                                                result = (Int32)cmd5.ExecuteNonQuery();
                                                SqlCeCommand cmd6 = conn.CreateCommand();
                                                cmd6.CommandText = "INSERT INTO TablePersona (Riga, IDPersona, Nome, Cognome, DataNascita, Peso) VALUES (" + lastrec + ",'" + athlete.AthleteID + "','" + athlete.LastName + "','" + athlete.FirstName + "',convert(datetime, '" + athlete.DOB + "',103)," + athlete.Weight + ")";
                                                //System.Windows.MessageBox.Show(cmd6.CommandText);
                                                int affectedRows = cmd6.ExecuteNonQuery();
                                                SqlCeCommand cmd7 = conn.CreateCommand();
                                                cmd7.CommandText = "SET IDENTITY_INSERT TablePersona OFF";
                                                result = (Int32)cmd7.ExecuteNonQuery();
                                                SqlCeCommand cmd8 = conn.CreateCommand();
                                                cmd8.CommandText = "INSERT INTO TablePesoPersona (IDPersona, Data, Peso) VALUES ('" + athlete.AthleteID + "',convert(nvarchar, getdate(), 103), cast((" + athlete.Weight + "/2.2046)*10 AS int))";
                                                result = (Int32)cmd8.ExecuteNonQuery();
      
                                            }
                                            catch (Exception Ex)
                                            {
                                                count++;
                                                if (Ex.Message.Substring(0, 11) == "A duplicate")
                                                {
                                                    extype = 1;
                                                    // System.Windows.Forms.Application.UseWaitCursor = false;
                                                    exmessage = athlete.FirstName + " " + athlete.LastName + " is already in database";
                                                }
                                                else
                                                {
                                                    extype = 2;
                                                    exmessage = Ex.Message;
                                                    System.Windows.Forms.Application.UseWaitCursor = false;
                                                }
                                                if (extype == 2)
                                                {
                                                    System.Windows.Forms.Application.UseWaitCursor = false;
                                                    System.Windows.MessageBox.Show(exmessage);
                                                }
                                            }
                                            try
                                            {
                                                SqlCeCommand cmd1 = conn.CreateCommand();
                                                cmd1.CommandText = "SET IDENTITY_INSERT TablePersona OFF";
                                                Int32 result = (Int32)cmd1.ExecuteNonQuery();
                                                SqlCeCommand cmd9 = conn.CreateCommand();
                                                cmd9.CommandText = "SET IDENTITY_INSERT TablePersonaNodo ON";
                                                result = (Int32)cmd9.ExecuteNonQuery();
                                                SqlCeCommand cmd3 = conn.CreateCommand();
                                                cmd3.CommandText = "INSERT INTO TablePersonaNodo (IDPersonaNodo, Nodo, Persona) VALUES (" + lastrec + ",'24e2fd4a-d217-4b38-935c-e7970ab8b666', '" + athlete.AthleteID + "')";
                                                int affectedRows = cmd3.ExecuteNonQuery();
                                                SqlCeCommand cmd4 = conn.CreateCommand();
                                                cmd4.CommandText = "SET IDENTITY_INSERT TablePersonaNodo OFF";
                                                result = (Int32)cmd4.ExecuteNonQuery();
                                            }
                                            catch (Exception Ex)
                                            {
                                                if (Ex.Message.Substring(0, 11) == "A duplicate")
                                                {
                                                    extype = 1;
                                                    // System.Windows.Forms.Application.UseWaitCursor = false;
                                                    exmessage = athlete.FirstName + " " + athlete.LastName + " is already in group.";
                                                }
                                                else
                                                {
                                                    extype = 2;
                                                    exmessage = Ex.Message;
                                                    System.Windows.Forms.Application.UseWaitCursor = false;
                                                }
                                                if (extype == 2)
                                                {
                                                    System.Windows.Forms.Application.UseWaitCursor = false;
                                                    System.Windows.MessageBox.Show(exmessage);
                                                }
                                            }
                                        }
                                        conn.Dispose();
                                        conn.Close();
                                        conn = new SqlCeConnection("Data Source = " + FileTextBox.Text + ";Default Lock Timeout=40000");
                                        conn.Open();
                                        int numrec = indb + (Athletes.Count - count) + 1;
                                        SqlCeCommand cmd12 = conn.CreateCommand();
                                        cmd12.CommandText = "SET LOCK_TIMEOUT 10000";
                                        int res = (Int32)cmd12.ExecuteNonQuery();
                                        SqlCeCommand cmd10 = conn.CreateCommand();
                                        cmd10.CommandText = "ALTER TABLE TablePersona ALTER COLUMN Riga IDENTITY (" + numrec + ", 1)";
                                        res = (Int32)cmd10.ExecuteNonQuery();
                                        SqlCeCommand cmd11 = conn.CreateCommand();
                                        cmd11.CommandText = "ALTER TABLE TablePersonaNodo ALTER COLUMN IDPersonaNodo IDENTITY (" + numrec + ", 1)";
                                        res = (Int32)cmd11.ExecuteNonQuery();
                                        conn.Dispose();
                                        conn.Close();
                                        System.Windows.Forms.Application.UseWaitCursor = false;
                                    }
                                    catch (Exception Ex)
                                    {
                                        System.Windows.Forms.Application.UseWaitCursor = false;
                                        System.Windows.MessageBox.Show(Ex.Message);
                                    }
                                }
                                System.Windows.MessageBox.Show((Athletes.Count) + " athletes downloaded. \n" + count + " already in the database. \n" + (Athletes.Count - count) + " added to database.");
                            }
                        }
                        catch (Exception ex)
                        {
                            System.Windows.Forms.Application.UseWaitCursor = false;
                            System.Windows.MessageBox.Show("Could not download athletes");
                        }
                    }
                }
                else
                {
                    System.Windows.MessageBox.Show("Please select an event");
                }
            }
        }

        private void btnTestdnld_Click(object sender, RoutedEventArgs e)
        {
            String exmessage;
            SqlCeConnection conn = null;
            Int32 extype = 0;
            Int32 count = 0;
            Int32 lastrec = 0;
            ApiOperations ops = new ApiOperations();
            if (FileTextBox.Text == "")
            {
                System.Windows.MessageBox.Show("Please select a database");
            }
            else
            {
                try
                {
                    List<Test> Tests = ops.GetTests(Globals.LoggedInUser);
                    if (Tests == null)
                    {
                        System.Windows.MessageBox.Show("There are no tests to download");
                    }
                    else
                    {
                        System.Windows.Forms.Application.UseWaitCursor = true;
                        // eventLog1.WriteEntry("In DBInfo.", EventLogEntryType.Information, eventId++);
                        try
                        {
                            conn = new SqlCeConnection("Data Source = " + FileTextBox.Text + ";Default Lock Timeout=10000");
                            conn.Open();
                            count = 0;
                            using (new CursorWait())
                            {
                                foreach (Test test in Tests)
                                {
                                    try
                                    {
                                        SqlCeCommand cmd = conn.CreateCommand();
                                        cmd.CommandText = "INSERT INTO TableDefProva (IDDefProva,Nome,Ambito,TipoProva,TipoPartenza,Partenza,TipoArrivo,Arrivo,NumSalti,Durata,Sequenza,NumCount,Note,Bloccato,Parametri,PiedePartenza,IndiciManuali,Template) VALUES ('" +
                                        test.IDDefProva + "','" + test.Nome + "'," + test.Ambito + "," + test.TipoProva + "," + test.TipoPartenza + "," + test.Partenza + "," + test.TipoArrivo + "," + test.Arrivo + "," + test.NumSalti + "," +
                                        test.Durata + "," + test.Sequenza + "," + test.NumCount + ",'" + test.Note + "'," + test.Bloccato + ",'" + test.Parametri + "'," + test.PiedePartenza + ",'" + test.IndiciManuali + "'," + test.Template + ")";
                                        // System.Windows.MessageBox.Show(cmd.CommandText);
                                        int affectedRows = cmd.ExecuteNonQuery();
                                        //Int32 result = (Int32)cmd.ExecuteNonQuery();
                                    }
                                    catch (Exception Ex)
                                    {
                                        count++;
                                        if (Ex.Message.Substring(0, 11) == "A duplicate")
                                        {
                                            extype = 1;
                                            // System.Windows.Forms.Application.UseWaitCursor = false;
                                            exmessage = test.Nome + " is already in database";
                                        }
                                        else
                                        {
                                            extype = 2;
                                            exmessage = Ex.Message;
                                        }
                                        if (extype == 2)
                                        {
                                            System.Windows.MessageBox.Show(exmessage);
                                        }
                                        //System.Windows.MessageBox.Show(Ex.Message);
                                    }
                                }
                            }
                            conn.Dispose();
                            conn.Close();
                            System.Windows.MessageBox.Show((Tests.Count) + " tests downloaded. \n" + count + " already in the database. \n" + (Tests.Count - count) + " added to database.");
                        }
                        catch (Exception ex)
                        {
                            System.Windows.Forms.Application.UseWaitCursor = false;
                            System.Windows.MessageBox.Show("Could not connect to database");
                        }
                    }
                }
                catch (Exception ex)
                {
                    System.Windows.Forms.Application.UseWaitCursor = false;
                    System.Windows.MessageBox.Show("Could not download tests");
                }
            }
        }
        private void btnFileSelect_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.OpenFileDialog openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            openFileDialog1.Filter = "sdf files(*.sdf)| *.sdf";
            DialogResult result = openFileDialog1.ShowDialog(); // Show the dialog.
            if (result == DialogResult.OK) // Test result.
            {
                string filename = openFileDialog1.FileName;
                FileTextBox.Text = filename;
            }
            //  Console.WriteLine(size); // <-- Shows file size in debugging mode.
            //  Console.WriteLine(result); // <-- For debugging use.
        }
        private void btnUpload_Click(object sender, EventArgs e)
        {
            SqlCeConnection conn = null;
            SqlCeDataReader rdr = null;
            String defprova = null;
            String selectcmd = null;
            Int32 count = 0;           
            if (FileTextBox.Text == "")
            {
                System.Windows.MessageBox.Show("Please select a database...");
            }
            else
            {
                if (EventBox.SelectedIndex >= 0)
                {
                    string selectedItem = EventBox.Items[EventBox.SelectedIndex].ToString();
                    foreach (Event ev in Globals.EventList)
                    {
                        if (ev.EventName == selectedItem)
                        {
                            selectedItem = ev.EventID;
                        }
                    }
                    if (selectedItem == "")
                    {
                        System.Windows.MessageBox.Show("Please select an event");
                    }
                    else
                    {
                        using (new CursorWait())
                        {
                            conn = new SqlCeConnection("Data Source = " + FileTextBox.Text + ";Default Lock Timeout=10000");
                            conn.Open();
                            SqlCeCommand cmd1 = conn.CreateCommand();
                            // System.Windows.MessageBox.Show(querystr);
                            cmd1.CommandText = "SELECT TOP (1) cast(IDDefProva as nvarchar(50)) FROM TableDefProva WHERE UPPER(Nome) = 'CMJ3' OR  UPPER(Nome) = 'CMJ 3'";
                            defprova = (String)cmd1.ExecuteScalar();
                            if (defprova != null)
                            {
                                selectcmd = "MIN(ContactTime) AS ContactTime, MAX(JumpHeight) AS JumpHeight, MAX(FlightTime) AS FlightTime";
                                count = SendUpload(defprova, selectedItem, "AVG", "/users/uploadathletes", selectcmd, FileTextBox.Text) + count;
                            }
                            cmd1.CommandText = "SELECT TOP (1) cast(IDDefProva as nvarchar(50)) FROM TableDefProva WHERE UPPER(Nome) = 'RIGHT 5 SINGLE LEG JUMPS'";
                            defprova = (String)cmd1.ExecuteScalar();
                            if (defprova != null)
                            {
                                selectcmd = "MIN(ContactTime) AS AVG_RL_GCT, MAX(FlightTime) AS AVG_RL_FT,MAX(JumpHeight) AS AVG_RL_Height";
                                count = SendUpload(defprova, selectedItem, "AVG", "/users/uploadrightleg", selectcmd, FileTextBox.Text) + count;
                            }
                            cmd1.CommandText = "SELECT TOP (1) cast(IDDefProva as nvarchar(50)) FROM TableDefProva WHERE UPPER(Nome) = 'RIGHT - 5 SINGLE LEG JUMPS'";
                            defprova = (String)cmd1.ExecuteScalar();
                            if (defprova != null)
                            {
                                selectcmd = "MIN(ContactTime) AS AVG_RL_GCT, MAX(FlightTime) AS AVG_RL_FT,MAX(JumpHeight) AS AVG_RL_Height";
                                count = SendUpload(defprova, selectedItem, "AVG", "/users/uploadrightleg", selectcmd, FileTextBox.Text) + count;
                            }
                            cmd1.CommandText = "SELECT TOP (1) cast(IDDefProva as nvarchar(50)) FROM TableDefProva WHERE UPPER(Nome) = 'LEFT 5 SINGLE LEG JUMPS'";
                            defprova = (String)cmd1.ExecuteScalar();
                            if (defprova != null)
                            // System.Windows.MessageBox.Show("There were no records to upload");
                            {
                                selectcmd = "MIN(ContactTime) AS AVG_LL_GCT, MAX(FlightTime) AS AVG_LL_FT,MAX(JumpHeight) AS AVG_LL_Height";
                                count = SendUpload(defprova, selectedItem, "AVG", "/users/uploadleftleg", selectcmd, FileTextBox.Text) + count;
                            }
                            cmd1.CommandText = "SELECT TOP (1) cast(IDDefProva as nvarchar(50)) FROM TableDefProva WHERE UPPER(Nome) = 'LEFT - 5 SINGLE LEG JUMPS'";
                            defprova = (String)cmd1.ExecuteScalar();
                            if (defprova != null)
                            // System.Windows.MessageBox.Show("There were no records to upload");
                            {
                                selectcmd = "MIN(ContactTime) AS AVG_LL_GCT, MAX(FlightTime) AS AVG_LL_FT,MAX(JumpHeight) AS AVG_LL_Height";
                                count = SendUpload(defprova, selectedItem, "AVG", "/users/uploadleftleg", selectcmd, FileTextBox.Text) + count;
                            }
                            cmd1.CommandText = "SELECT TOP (1) cast(IDDefProva as nvarchar(50)) FROM TableDefProva WHERE UPPER(Nome) = 'REAZIONE OTTICA'";
                            defprova = (String)cmd1.ExecuteScalar();
                            if (defprova != null)
                            // 
                            {
                                selectcmd = "MIN(ReactionTime) AS Best_Reaction_Time";
                                count = SendUpload(defprova, selectedItem, "MIN", "/users/uploadmreaction", selectcmd, FileTextBox.Text) + count;
                                selectcmd = "MIN(ReactionTime) AS AVG_Reaction_Time, MAX(JumpHeight) AS AVG_Reaction_Height";
                                int cnt1 = SendUpload(defprova, selectedItem, "AVG", "/users/uploadareaction", selectcmd, FileTextBox.Text);
                            }
                            conn.Close();
                        }
                        if (count == 0)
                        {
                            System.Windows.MessageBox.Show("There were no records to upload");
                        }
                        else
                        {
                            System.Windows.MessageBox.Show(count + " records uploaded");
                        }
                    }
                }
                else
                {
                    System.Windows.MessageBox.Show("Please select an event");
                }
            }
        }
        private int SendUpload(string defprova, string selectedItem, string rowtype, string sendurl, string selectcmd, string datasrc)
        {
            string jsonstring;
            Int32 Result;
            SqlCeConnection conn = null;
            SqlCeDataReader rdr = null;
            Int32 count = 0;
            // System.Windows.MessageBox.Show("There were no records to upload");
            conn = new SqlCeConnection("Data Source = " + datasrc + ";");
            conn.Open();
            SqlCeCommand cmd = conn.CreateCommand();
            string querystr = "SELECT '" + Globals.LoggedInUser.OrganizationID + "' AS OrgID,'" + selectedItem + "' AS EventID, TableProva.Persona, MAX(TablePersona.Nome) AS Nome, MAX(TablePersona.Cognome) AS Cognome, " + selectcmd + " FROM TableResultData JOIN TableProva ON TableProva.IDProva = TableResultData.IDProva JOIN TablePersona ON TablePersona.IDPersona = TableProva.Persona WHERE RowType = '" + rowtype + "' AND TableProva.DefProva = '" + defprova + "' GROUP BY TableProva.Persona";
            // System.Windows.MessageBox.Show(querystr);
            cmd.CommandText = "SELECT count(*) AS count FROM (SELECT DISTINCT TableProva.Persona FROM TableResultData JOIN TableProva ON TableProva.IDProva = TableResultData.IDProva WHERE RowType = '" + rowtype + "' AND TableProva.DefProva = '" + defprova + "')x";
            count = (Int32)cmd.ExecuteScalar();
            if (count == 0)
            {
                return 0;
                //   System.Windows.MessageBox.Show("There were no records to upload");
            }
            else
            {
                cmd = new SqlCeCommand(querystr, conn);
                rdr = cmd.ExecuteReader();
                jsonstring = string.Empty;
                jsonstring = sqlDatoToJson(rdr);
                // System.Windows.MessageBox.Show(jsonstring);
                Result = SendJSON(jsonstring, sendurl);
                if (Result == 0)
                {
                   return count;
                }
                if (Result == 1)
                {
                    System.Windows.MessageBox.Show("Table Result Data Send Failure.");
                    return 0;
                }
                if (Result == 2)
                {
                    System.Windows.MessageBox.Show("Table Result Data Exception.");
                    return 0;
                }
                rdr.Dispose();
                rdr.Close();
                return 0;
            }
        }
    }
}
